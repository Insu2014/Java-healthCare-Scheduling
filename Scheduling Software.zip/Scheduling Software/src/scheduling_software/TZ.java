/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scheduling_software;

/**
 *
 * @author Suraj
 */
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.logging.Level;
import java.util.logging.Logger;

public class TZ {
    public static void main(String[] args) {
        Locale locale = Locale.getDefault();
        //TimeZone localTimeZone = TimeZone.getDefault(); 
        TimeZone localTimeZone = TimeZone.getTimeZone("Australia/Sydney");
        //DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.FULL, DateFormat.FULL, locale);
        String dt=connection.fetchItem("select start from appointment where appointmentid=20", "start");
        SimpleDateFormat formatter=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date datee=null;
        try {
            datee=formatter.parse(dt);
        } catch (ParseException ex) {
            Logger.getLogger(UpdateAppointment.class.getName()).log(Level.SEVERE, null, ex);
        }
         Calendar cal = Calendar.getInstance();
        long milliDiff = cal.get(Calendar.ZONE_OFFSET);
            // Got local offset, now loop through available timezone id(s).
            String [] ids = TimeZone.getAvailableIDs();
            String name = null;
            for (String id : ids) {
              TimeZone tz = TimeZone.getTimeZone(id);
              if (tz.getRawOffset() == milliDiff) {
                // Found a match.
                name = id;
                break;
              }
            }
            System.out.println(name);
        formatter.setTimeZone(localTimeZone);
        System.out.println(locale.toString() + ": " + formatter.format(datee));
    }
}
