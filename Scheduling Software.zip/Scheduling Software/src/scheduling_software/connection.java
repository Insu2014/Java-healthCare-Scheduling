/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scheduling_software;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Suraj
 */
public class connection {
 
 //static String constring = "jdbc:mysql://localhost:3306/scheduling_software";
 //static String username = "root";
 //static String password = "";
 static String constring = "jdbc:mysql://52.206.157.109:3306/U04qKI";
 static String username = "U04qKI";
 static String password = "53688317850";
 
 
  public static boolean Insert(String sql){
      Connection con = null;
      Statement s = null;
     try
     {
        con = DriverManager.getConnection(constring, username, password);
        //prepare stmnset
        s = con.prepareStatement(sql);
        s.execute(sql);
        return true;
     }
     catch(SQLException e){ //SQLException
         return false;
     }finally{
          try{
              if(s!=null)s.close();
              if(con!=null)con.close();
          }catch(Exception e){
             JOptionPane.showMessageDialog(null, e); 
          }
      } 
  }    

  public static boolean Update(String sql){
     Connection con = null;
     Statement s = null;
      try
     {
        con = DriverManager.getConnection(constring, username, password);
        //prepare stmnset
        s = con.prepareStatement(sql);
        s.execute(sql);
        return true;
     }
     catch(SQLException e){
         JOptionPane.showMessageDialog(null, e);
         return false;
     }finally{
          try{
              if(s!=null)s.close();
              if(con!=null)con.close();
          }catch(SQLException e){
             JOptionPane.showMessageDialog(null, e); 
          }
      }
  }   
  
  public static DefaultTableModel PopulateTable(String sql){
     Connection con = null;
     Statement s = null;
     try{
        con = DriverManager.getConnection(constring, username, password); 
        s = con.prepareStatement(sql);       
        ResultSet rs = s.executeQuery(sql);
        ResultSetMetaData metadata = rs.getMetaData();
        
        Vector<String> ColumNames = new Vector<String>();
        int ColumnCount = metadata.getColumnCount();
        
        for(int column=1; column<=ColumnCount; column++){
            ColumNames.add(metadata.getColumnName(column));
        }
        //names of columns
        Vector<Vector<Object>> data = new Vector<Vector<Object>>();
        
        while(rs.next()){
           Vector<Object> vector = new Vector<Object>(); 
           
           for(int columindex=1; columindex<=ColumnCount; columindex++){
               vector.add(rs.getObject(columindex));
           }
           data.add(vector);
        }
        
        return new DefaultTableModel(data, ColumNames);
     }catch(SQLException e){
         new JOptionPane().showMessageDialog(null, e);
         return null;
     }finally{
          try{
              if(s!=null)s.close();
              if(con!=null)con.close();
          }catch(SQLException e){
             JOptionPane.showMessageDialog(null, e); 
          }
      }
   }
 
 public static DefaultComboBoxModel Fetch(String sql,String columName){
     DefaultComboBoxModel dcm = new DefaultComboBoxModel();
     Connection con = null;
     Statement s = null;
     try{
        con = DriverManager.getConnection(constring, username, password); 
        s = con.prepareStatement(sql);
        
        ResultSet rs = s.executeQuery(sql);
        //loop
        while(rs.next()){
            
            String name = rs.getString(columName);
            dcm.addElement(name);
             //new JOptionPane().showMessageDialog(null, name);
        }
        return dcm;
     }catch(SQLException e){
         e.printStackTrace();
         return null;
     }finally{
          try{
              if(s!=null)s.close();
              if(con!=null)con.close();
          }catch(SQLException e){
             JOptionPane.showMessageDialog(null, e); 
          }
      }
   } 
  
 public static String fetchItem(String sql,String columName){
     Connection con = null;
     Statement s = null;
     try{
         con = DriverManager.getConnection(constring, username, password); 
         s = con.prepareStatement(sql);
        
        ResultSet rs = s.executeQuery(sql);
        String name=null;
        //loop
        while(rs.next()){
            
           name = rs.getString(columName);
        }
        return name;
     }catch(SQLException e){
         JOptionPane.showMessageDialog(null, e);
         return null;
     }finally{
          try{
              if(s!=null)s.close();
              if(con!=null)con.close();
          }catch(SQLException e){
             JOptionPane.showMessageDialog(null, e); 
          }
      }
 }
 
   
}
