/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scheduling_software;

/**
 *
 * @author Suraj
 */
import java.time.*;
import java.time.format.*;

public class Test {
    public static void main(String[] args) {
        String str = "16Jun2015_153556";
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("ddMMMyyyy_HHmmss");
        ZoneId zone = ZoneId.of("America/New_York");
        LocalDateTime dateTime = LocalDateTime.parse(str, formatter);
        ZonedDateTime zoned = ZonedDateTime.of(dateTime, zone);

        // Both of these print 2015-06-16T19:35:56Z
        System.out.println(zoned.toInstant().toString()); 
        System.out.println(zoned.withZoneSameInstant(ZoneOffset.UTC).getHour());
    }
}