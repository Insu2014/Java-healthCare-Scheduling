/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scheduling_software;

/**
 *
 * @author Suraj
 */
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
import org.json.*;

public class Location{
    
    static Client client;
    static Response response;
    JSONObject data;
    String ip;
    public Location() throws JSONException, Exception{
        ip=IpChecker.getIp();
        client = ClientBuilder.newClient();
        response=client.target("https://api.ipdata.co/"+ip+"?api-key=test").request(MediaType.APPLICATION_JSON).header("Accept", "application/json").get();
        data=new JSONObject(response.readEntity(String.class));
    }
    public String getContinent() throws JSONException{ //JSONException
        return data.getString("continent_name");
    }
    public String getCountry() throws JSONException{
        return data.getString("country_name");
    }
    public String getCity() throws JSONException{
        return data.getString("city");
    }
}