/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scheduling_software;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author Suraj
 */
public class Checker extends Thread{
    int count;
    public Checker(int count){
        this.count=count;
    }
    @Override
    public void run(){
        try{
            System.out.println ("Thread " + 
                  Thread.currentThread().getId() + 
                  " is running"); 
            ScheduledExecutorService exec = Executors.newSingleThreadScheduledExecutor();
        exec.scheduleAtFixedRate(new Runnable() {
          @Override
          public void run() {
            //create a new thread to check whether a new appointment has been made
            int newCount=Integer.parseInt(connection.fetchItem("select count(appointmentid) from appointment", "count(appointmentid)"));
            if(newCount>count){
                int diff=newCount-count;
                new Notifier(diff+ "new appointments have been made in the last 15 minutes").setVisible(true);
                count=newCount;
            }
          }
        }, 0, 15, TimeUnit.SECONDS);
           
            
        }catch(NumberFormatException e){
            System.out.println(e.getMessage());
        }
    }
}
